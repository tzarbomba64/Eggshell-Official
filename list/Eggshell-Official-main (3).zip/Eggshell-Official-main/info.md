# Extra information

Eggshell should not be used with first installing add-ons, add-ons allow users to add and create their own commands.

To download a scaffold of a broken 'Cube.egg' file, please use: https://github.com/tzarbomba64/Eggshell/blob/main/cube.egg
