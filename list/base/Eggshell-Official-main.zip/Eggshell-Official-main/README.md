# Eggshell-Official
Worse than terminal™

![image](https://github.com/user-attachments/assets/4c22156d-c2be-4e5b-81d1-1865072d1134)
# How to use
Has few pre-installed commands. To add commands:
1. Make a new github repository.
2. Upload a text file with the '.egg' extension. See https://github.com/tzarbomba64/Eggshell for example EGG files.
3. On Eggshell, run 'imp [github username] [github repository name]'.

# Tips and Tricks
1. To see extended logging for testing EGG files, run 'debug'.
2. ALways make sure commands line up with function names properly in EGG files

# Files
